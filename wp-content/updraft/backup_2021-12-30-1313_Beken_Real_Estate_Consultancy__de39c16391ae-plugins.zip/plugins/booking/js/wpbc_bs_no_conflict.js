var wpbc_modal = jQuery.fn.modal.noConflict(); 
jQuery.fn.wpbc_modal = wpbc_modal;